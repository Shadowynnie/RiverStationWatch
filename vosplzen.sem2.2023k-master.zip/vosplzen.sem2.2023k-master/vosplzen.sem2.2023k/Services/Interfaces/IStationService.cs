﻿using vosplzen.sem2._2023k.Data;
using vosplzen.sem2._2023k.Data.Model;

namespace vosplzen.sem2._2023k.Services
{
    public interface IStationService
    {

        public void AddStation(Station station);

    }
}
