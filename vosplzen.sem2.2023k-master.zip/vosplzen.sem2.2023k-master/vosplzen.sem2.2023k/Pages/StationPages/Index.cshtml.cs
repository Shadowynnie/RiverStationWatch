using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace vosplzen.sem2._2023k.Pages.StationPages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
